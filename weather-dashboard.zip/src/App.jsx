import { useState, useEffect } from 'react';
import axios from 'axios';
import SearchBar from './components/SearchBar';
import WeatherCard from './components/WeatherCard';
import { motion } from 'framer-motion';

const API_KEY = 'YOUR_API_KEY'; // Replace with your actual API key

function App() {
  const [city, setCity] = useState('');
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [recent, setRecent] = useState(() => {
    return JSON.parse(localStorage.getItem('recentCities')) || [];
  });

  useEffect(() => {
    localStorage.setItem('recentCities', JSON.stringify(recent));
  }, [recent]);

  const fetchWeather = async (cityName) => {
    setLoading(true);
    setError('');
    try {
      const res = await axios.get(
        \`https://api.openweathermap.org/data/2.5/weather?q=\${cityName}&appid=\${API_KEY}&units=metric\`
      );
      setWeather(res.data);
      setCity(cityName);
      const updated = [cityName, ...recent.filter((c) => c !== cityName)].slice(0, 5);
      setRecent(updated);
    } catch (err) {
      setError('City not found or API error');
      setWeather(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-xl">
      <SearchBar onSearch={fetchWeather} />

      {recent.length > 0 && (
        <div className="mt-4 flex flex-wrap gap-2">
          {recent.map((item, index) => (
            <button
              key={index}
              onClick={() => fetchWeather(item)}
              className="bg-white px-3 py-1 rounded shadow text-sm"
            >
              {item}
            </button>
          ))}
        </div>
      )}

      {loading && <p className="mt-4 animate-pulse">Loading weather data...</p>}
      {error && <p className="mt-4 text-red-600">{error}</p>}
      {weather && (
        <motion.div
          className="mt-6"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <WeatherCard data={weather} />
        </motion.div>
      )}
    </div>
  );
}

export default App;
